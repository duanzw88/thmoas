#include <stdlib.h>
#include <stdio.h>

#include "assert.h"
#include "mem.h"
#include "matrix.h"

#define T matrix_t

struct T
{
	int row;	//矩阵的行数
	int col;	//矩阵的列数
	double *data;
};
/**
 * 新建矩阵，矩阵中各值初始化为0.0
 * @param  row 新矩阵的行数
 * @param  col 新矩阵的列数
 * @return     新的矩阵
 */
T 	matrix_new(int row,int col)
{
	T matrix;
	int i;
	assert(row > 0 && col > 0);

	matrix = ALLOC(sizeof(matrix) + sizeof(double) * (row * col));
	matrix->row = row;
	matrix->col = col;
	matrix->data = (double *)(matrix + 1);
	for(i = 0;i < row * col;i++)
	{
		// printf("i = %d\n",i);
		matrix->data[i] = 0.0;
	}

	return matrix;
}
/**
 * 打印矩阵
 * @param  matrix 目标矩阵
 * @return        无
 */
void	matrix_print(T matrix)
{
	int i;
	assert(matrix);
	for(i = 0; i < matrix->row * matrix->col;i++)
	{
		printf("%.4f\t",matrix->data[i]);
		if( (i+1) % matrix->col == 0 )
		{
			printf("\n");
		}

	}
	printf("\n");

}
/**
 * 获取矩阵的行数
 * @param  matrix 目标矩阵
 * @return        返回矩阵行数
 */
int  matrix_get_row(T matrix)
{
	assert(matrix);
	return matrix->row;
}
/**
 * 获取矩阵列数
 * @param  matrix 目标矩阵
 * @return        返回矩阵列数
 */
int 	matrix_get_col(T matrix)
{
	assert(matrix);
	return matrix->col;
}
/**
 * 设置矩阵的值
 * @param  matrix 目标矩阵
 * @param  row    新值所在的行
 * @param  col    新值所在的列
 * @param  value  新值
 * @return        1 新值添加成功
 *                0 新值添加失败
 */
int 	matrix_put(T matrix,int row,int col,double value)
{
	assert(matrix);
	assert(row > 0 && col > 0);
	assert(row <= matrix->row && col <= matrix->col);

	int index = (row-1) * matrix->col + (col-1);
	matrix->data[index] = value;

	return 0;
}
/**
 * 获取矩阵的一个值
 * @param  matrix 目标矩阵
 * @param  row    要获取值所在的行
 * @param  col    要获取的值所在的列
 * @return        返回获取的值
 */
double 	matrix_get(T matrix,int row,int col)
{
	assert(matrix);
	assert(row > 0 && col > 0);
	assert(row <= matrix->row && col <= matrix->col);

	int index = (row-1) * matrix->col + (col-1);
	return matrix->data[index];
}
/**
 * 两个矩阵相加
 * @param  matrix1 目标矩阵1
 * @param  matrix2 目标矩阵2
 * @return         返回相加的结果矩阵
 */
T matrix_add(T matrix1,T matrix2)
{
	T matrix;
	int i,j;
	assert(matrix1 && matrix2);
	assert(matrix1->row ==  matrix2->row);
	assert(matrix1->col == matrix2->col);

	int row = matrix1->row;
	int col = matrix1->col;
	matrix = matrix_new(row,col);
	for(i = 1;i <= row;i++)
	{
		for(j = 1;j <= col;j++)
		{
			int value1 = matrix_get(matrix1,i,j);
			int value2 = matrix_get(matrix2,i,j);
			matrix_put(matrix,i,j,value1 + value2);
		}
	}

	return matrix;

}
/**
 * 两个矩阵相减matrix1-matrix2
 * @param  matrix1 被减矩阵
 * @param  matrix2 减数矩阵
 * @return         返回结果矩阵
 */
T 		matrix_sub(T matrix1,T matrix2)
{
	T matrix;
	int i,j;
	assert(matrix1 && matrix2);
	assert(matrix1->row ==  matrix2->row);
	assert(matrix1->col == matrix2->col);

	int row = matrix1->row;
	int col = matrix1->col;
	matrix = matrix_new(row,col);
	for(i = 1;i <= row;i++)
	{
		for(j = 1;j <= col;j++)
		{
			int value1 = matrix_get(matrix1,i,j);
			int value2 = matrix_get(matrix2,i,j);
			matrix_put(matrix,i,j,value1 - value2);
		}
	}

	return matrix;
}

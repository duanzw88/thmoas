/**
 * @file 	ring.c
 * @author 	duanzw
 * @date	2016/3/22
 * @version 0.1.0
 * @brief	环与序列非常相似:它包含N个值，分别关联到整数索引0到N-1(N为正值)
 *        	空的环不包含任何值，其中的值都是指针
 *        	值可以添加到环中的任意位置，同样环中的任何值都可以被删除
 *        	左旋:将环中的每个值的索引-n并对环的长度取模
 *        	右旋:将环中的每个值的索引+n并对环的长度取模
 *        	虽然在环中可以在任意位置添加/删除值，但是这种灵活性的代价是访问第i个值不保证在常数时间内完成
 *
 */

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "assert.h"
#include "mem.h"
#include "ring.h"

#define T ring_t

/**
 * 环是双向链表的抽象，向环中接口的任何例程传递的T值为NULL，都是已检查的运行时错误
 * head字段指向有node结构构成的一个双向链表，node结构中的value字段保存了环中的值
 * head指向关联到索引0的值，后续保证在通过rlink字段链接的各点中，各点的llink字段指向其前趋
 * 空环的length字段为0 head字段为NULL
 */
struct T
{
	struct node
	{
		struct node *llink,*rlink;
		void *value;
	}*head;
	int length;
};
/**
 * 创建一个空环
 * @return  返回新创建的空环
 */
 T 		ring_new(void)
 {
	 T ring;

	 NEW0(ring);
	 ring->head = NULL;

	 return ring;

 }

 /**
  * 创建并返回一个环，用非NULL的值来初始化环中的值，参数列表结束于第一个NULL指针参数
  * @param  x       环的第一个元素
  * @param  VARARGS 非NULL值来初始化环中的值
  * @return         返回根据参数新建的环
  *
  * ps：参数列表的可变部分传递的指针假定为void指针，因此在传递char或void以外的指针时
  * 		需要程序员提供转换
  * eg:ring_t names = ring_ring("Lists","Tables","Sets",NULL);
  * 	会给出3个值的一个换，赋值给names，参数列表中的值将关联到索引0-2
  */
 T 		ring_ring(void *x, ...)
 {
	 va_list ap;

	 //创建一个空环
	 T ring = ring_new();

	 va_start(ap,x);
	 for(; x; x = va_arg(ap,void *))
	 {
		 //将各指针参数添加大环的末尾
		 ring_addhi(ring,x);
	 }
	 va_end(ap);

	 return ring;
 }

/**
 * 释放*ring指定的环，并将*ring清零
 * @param  ring 目标环
 */
 void 	ring_free(T *ring)
 {
	 struct node *p,*q;

	 assert(ring && *ring);
	 if( (p = (*ring)->head) != NULL)
	 {
		 int n = (*ring)->length;
		 //首先释放各个node的结构实例
		 for(; n-- > 0; p = q)
		 {
			 q = p->llink;
			 FREE(p);
		 }
	 }
	 //最后释放ring_t结构实例，即环的首部
	 FREE(*ring);
 }

/**
 * 环的长度（环中值的数目）
 * @param  ring 目标环
 * @return      目标环的长度
 */
 int 		ring_length(T ring)
 {
	 assert(ring);
	 return ring->length;
 }

/**
 * 获取环中的索引为i的值
 * @param  ring 目标环
 * @param  i    索引值
 * @return      索引i的值
 */
 void 	*ring_get(T ring,int i)
 {
	 struct node *q;

	 assert(ring);
	 assert(i >= 0 && i < ring->length);

	 //最短路径找到第i个节点
	 {
		 int n;
		 q = ring->head;
		 if(i <= ring->length / 2)
		 {
			 //顺时针方向找到想要的点
			 for(n = i; n-- > 0;)
			 {
				 q= q->rlink;
			 }
		 }
		 else
		 {
			 //逆时针方向找到目标节点
			 for(n = ring->length - i;n-- > 0;)
			 {
				 q = q->llink;
			 }
		 }
	 }

	 return q->value;
 }

/**
 * 更新环中索引为i的值
 * @param  ring 目标环
 * @param  i    索引
 * @param  x    新值
 * @return      返回原值
 */
 void 	*ring_put(T ring,int i,void *x)
 {
	 struct node *q;
	 void *prev;

	 assert(ring);
	 assert(i >= 0 && i < ring->length);

	 {
		 int n;
		 q = ring->head;
		 if(i <= ring->length / 2)
		 {
			 for(n = i; n-- > 0;)
			 {
				 q= q->rlink;
			 }
		 }
		 else
		 {
			 for(n = ring->length - i;n-- > 0;)
			 {
				 q = q->llink;
			 }
		 }
	 }

	 prev = q->value;
	 q->value = x;

	 return prev;
 }

/**
 * 在环中添加新值,添加新值后，其右侧的所有值的索引+1，环的长度+1
 * @param  ring 目标环
 * @param  pos  要添加的新值的位置
 * @param  x    要添加的值
 * @return      返回新值
 */
 void 	*ring_add(T ring,int pos,void *x)
 {
	 assert(ring);
	 assert(pos >= -ring->length && pos <= ring->length + 1);

	 if(pos == 1 || pos == -ring->length)
	 {
		 return ring_addlo(ring,x);
	 }
	 else if(pos == 0 || pos == ring->length + 1)
	 {
		 return ring_addhi(ring,x);
	 }
	 else
	 {
		 struct node *p,*q;
		 int i = pos < 0 ? pos + ring->length : pos - 1;
		 {
			 int n;
			 q = ring->head;
			 if(i <= ring->length / 2)
			 {
				 for(n = i; n-- > 0;)
				 {
					 q= q->rlink;
				 }
			 }
			 else
			 {
				 for(n = ring->length - i;n-- > 0;)
				 {
					 q = q->llink;
				 }
			 }
		 }

		 NEW(p);
		 {
			 p->llink = q->llink;
			 q->llink->rlink = p;
			 p->rlink = q;
			 q->llink = p;
		 }
		 ring->length++;
		 return p->value = x;
	 }
 }

/**
 * 等效于ring_add(ring,1,x)在开始出添加新值
 * @param  ring 目标环
 * @param  x    要添加的新值
 * @return      返回新值
 */
 void 	*ring_addlo(T ring,void *x)
 {
	 assert(ring);

	 ring_addhi(ring,x);
	 ring->head = ring->head->llink;


	 return x;
 }

/**
 * 等效于ring_add(ring,0,x)在尾部添加新值
 * @param  ring 目标环
 * @param  x    要添加的新值
 * @return      返回新值
 */
 void 	*ring_addhi(T ring,void *x)
 {
	 struct node *p,*q;

	 assert(ring);
	 NEW(p);
	 if( (q = ring->head) != NULL)
	 {
		 p->llink = q->llink;
		 q->llink->rlink = p;
		 p->rlink = q;
		 q->llink = p;
	 }
	 else
	 {
		 //向空环添加一个值
		 ring->head = p->llink = p->rlink = p;
	 }
	 ring->length++;

	 return p->value = x;
 }

/**
 * 在环中根据索引值删除值，删除后其右侧剩下的值索引都-1，环的长度-1
 * @param  ring 目标环
 * @param  i    索引值
 * @return      返回删除的值
 */
 void 	*ring_remove(T ring,int i)
 {
	 void *x;
	 struct node *q;

	 assert(ring);
	 assert(ring->length > 0);
	 assert(i >= 0 && i < ring->length);

	 {
		 int n;
		 q = ring->head;
		 if(i <= ring->length / 2)
		 {
			 for(n = i; n-- > 0;)
			 {
				 q= q->rlink;
			 }
		 }
		 else
		 {
			 for(n = ring->length - i;n-- > 0;)
			 {
				 q = q->llink;
			 }
		 }
	 }
	 if(i == 0)
	 {
		 ring->head = ring->head->rlink;
	 }

	 x = q->value;
	 q->llink->rlink = q->rlink;
	 q->rlink->llink = q->llink;
	 FREE(q);
	 if(--ring->length == 0)
	 {
		 ring->head = NULL;
	 }
	 return x;
 }

/**
 * 删除环低端(开始处)的值，等效于ring_remove(ring,0)
 * @param  ring 目标环
 * @return      返回删除的值
 */
 void 	*ring_remlo(T ring)
 {
	 assert(ring);
	 assert(ring->length > 0);

	 ring->head = ring->head->rlink;
	 return ring_remhi(ring);
 }

/**
 * 删除环高端(末尾)的值，等效于ring_remove(ring,ring_length(ring)-1)
 * @param  ring 目标环
 * @return      返回删除的值
 */
void 	*ring_remhi(T ring)
{
	void *x;
	struct node *q;

	assert(ring);
	assert(ring->length > 0);

	q = ring->head->llink;
	x = q->value;

	q->llink->rlink = q->rlink;
	q->rlink->llink = q->llink;
	FREE(q);
	if(--ring->length == 0)
	{
		ring->head = NULL;
	}
	return x;
}

/**
 * 将环左旋或右旋
 * @param  ring 目标环
 * @param  n    n>0 将换右旋n个值，n<0将环左旋n个值
 *
 * @other n模环的长度为0的话 该函数没有效果，
 *        n的绝对值大于ring的长度，是已检查的运行时错误
 */
void 	ring_rotate(T ring,int n)
{
	struct node *q;
	int i;

	assert(ring);
	assert(n >= -ring->length && n <= ring->length);

	if(n >= 0)
	{
		i = n % ring->length;
	}
	else
	{
		i = n + ring->length;
	}

	{
		int n;
		q = ring->head;
		if(i <= ring->length / 2)
		{
			for(n = i; n-- > 0;)
			{
				q= q->rlink;
			}
		}
		else
		{
			for(n = ring->length - i;n-- > 0;)
			{
				q = q->llink;
			}
		}
	}

	ring->head = q;

}

/**
 * @file 	bit.c
 * @author 	duanzw
 * @date	2016/3/22
 * @version 0.1.0
 * @brief	Bit接口导出了操作位向量的函数，位向量可用于表示0到N-1的整数集合
 *        	Bit接口提供了set接口中大部分集合操作函数，以及少量特定于位向量的函数
 *        	由位向量表示的集合有一个明确的全集 即从0到N-1的所有整数构成的集合
 *
 */

#include <stdarg.h>
#include <string.h>
#include "assert.h"
#include "mem.h"
#include "bit.h"


#define T bit_t

struct T
{
			 int 	length;
	unsigned char 	*bytes;
	unsigned char 	*words;
};

#define BPW (8 * sizeof(unsigned long))
#define nbytes(len) ((((len) + 8 - 1) & (~(8-1))) / 8)
#define nwords(len) ((((len) + BPW -1) & (~(BPW-1))) / BPW)
/**
 * 创建一个包含length个比特位的新向量，并将所有bit位都设置为0
 * @param  length 新向量bit位的长度
 * @return        返回新的向量
 */
T 		bit_new(int length)
{
	T set;

	assert(length >= 0);
	NEW(set);
	if(length > 0)
	{
		set->words = CALLOC(nwords(length),sizeof(unsigned long));
	}
	else
	{
		set->words = NULL;
	}

	set->bytes = (unsigned char *)set->words;
	set->length = length;

	return set;
}

/**
 * 返回向量中的bit位数
 * @param  set 目标向量
 * @return     返回bit的位数
 */
int 		bit_length(T set)
{
	assert(set);
	return set->length;
}

/**
 * 查询向量中1的数目，即置位的比特位数
 * @param  set 目标向量
 * @return     返回目标向量中1的个数
 */
int 		bit_count(T set)
{
	int length = 0,n;
	static char count[] = {0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4};

	assert(set);
	for(n = nbytes(set->length);--n>=0;)
	{
		unsigned char c = set->bytes[n];
		length += count[c & 0xF] + count[c>>4];
	}

	return length;
}

/**
 * 释放*set并将*set清零
 * @param  set 目标bit集合
 * @return     无
 */
void 	bit_free(T *set)
{
	assert(set && *set);
	FREE((*set)->words);
	FREE(*set);
}

/**
 * 获取比特位n
 * @param  set 比特位集合
 * @param  i   索引
 * @return     返回bit位n
 */
int 		bit_get(T set,int i)
{
	return 0;
}

/**
 * 将集合中bit位n设置为bit
 * @param  set 比特位集合
 * @param  n   比特位索引
 * @param  bit 新值
 * @return     返回该比特位原值
 */
int 		bit_put(T set,int n,int bit)
{
	return 0;
}
/**
 * 将lo到hi的所有比特位清零
 * @return     无
 */
void 	bit_clear(T set,int lo,int hi)
{

}
/**
 * 将lo到hi的所有比特位置位
 * @return     无
 */
void 	bit_set(T set,int lo,int hi)
{

}
/**
 * 将lo到hi的所有比特位取反
 * @return     无
 */
void 	bit_not(T set,int lo,int hi)
{

}

/**
 * @return   s ⊂ t 返回1 否则返回0
 */
void 	bit_lt(T s,T t)
{

}
/**
 * @return   s = t 返回1 否则返回0
 */
void 	bit_eq(T s,T t)
{

}
/**
 * @return   s ⊆ t 返回1 否则返回0
 */
void 	bit_leq(T s,T t)
{

}

void 	bit_map(T set,void apply(int n,int bit,void *cl),void *cl)
{

}

//集合操作
//并集
T 		bit_union(T s,T t)
{
	return NULL;
}
//交集
T 		bit_inter(T s,T t)
{
	return NULL;
}
//差集
T 		bit_mins(T s,T t)
{
	return NULL;
}
//对称差
T 		bit_diff(T s,T t)
{
	return NULL;
}

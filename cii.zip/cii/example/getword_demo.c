#include <stdio.h>
#include "getword.h"
#include <time.h>

int main(int argc,char *argv[])
{

	
	int i;
	char buf[128];

	if(argc < 2)
	{
		printf("Us:main file");
		return -1;
	}
	for(i = 1;i < argc;i++)
	{
		FILE *fp = fopen(argv[i],"r");
		if(fp == NULL)
		{
			printf("%s:cannot open\n",argv[i]);
			return -1;
		}

		while(!feof(fp))
		{
			const char *line = readline(fp);
			printf("%s\n",line);
		}
	}


	return 0;
}

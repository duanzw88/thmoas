#include <stdio.h>
#include "ring.h"

int main(int argc,char *argv[])
{
	long i,tmp;
	ring_t ring;
	ring = ring_new();
	for(i = 0;i < 1024;i++)
	{
		ring_addhi(ring,(void *)i);
	}
	printf("ring length = %d\n",ring_length(ring));

	tmp = ring_remhi(ring);
	printf("remove %ld length = %d\n",tmp,ring_length(ring));

	tmp = ring_addhi(ring,tmp);
	printf("add %ld length = %d\n",tmp,ring_length(ring));

	tmp = ring_remlo(ring);
	printf("remove %ld length = %d\n",tmp,ring_length(ring));
	tmp = ring_addlo(ring,tmp);
	printf("add %ld length = %d\n",tmp,ring_length(ring));
	//
	tmp = ring_remove(ring,10);
	printf("remove %ld length = %d\n",tmp,ring_length(ring));
	tmp = ring_add(ring,10,tmp);
	printf("add %ld length = %d\n",tmp,ring_length(ring));

	printf("ring 15 is:%d\n",ring_get(ring,15));
	ring_rotate(ring,15);
	printf("After rotate_15 the ring 15 is:%d\n",ring_get(ring,15));
	return 0;
}

#include <stdio.h>

#include "arena.h"

int main()
{
	arena_t arena = arena_new();

//	printf("init arena = %p\n",arena);
	printf("-----------malloc 10---------");
	arena_alloc(arena,10,__FILE__,__LINE__);
	printf("-----------malloc 10*1024*1024---------");
	arena_alloc(arena,10*1024*1024,__FILE__,__LINE__);
	return 0;
}
#include <stdio.h>
#include <time.h>
#include "atom.h"

#define N 10
/*
*输入随机生成字符串的个数n
*测量atom_new的速度
*测量各个链表的长度
*/

//生成随机字符串
char *getRandomString(int length)
{
	int flag,i;
	char *string;

	srand((unsigned)time(NULL));
	if((string = (char *)malloc(length + 1)) == NULL)
	{
		printf("malloc string fail...\n");
		return NULL;
	}

	for(i = 0;i < length;i++)
	{
		flag = rand() % 3;
		switch(flag)
		{
			case 0:
				string[i] = '0' + rand() % 10;
				break;
			case 1:
				string[i] = 'A' + rand() % 26;
				break;
			case 2:
				string[i] = 'a' + rand() % 26;
				break;
			default:
				break;
		}

	}

	string[length] = '\0';

	return string;
}
int main()
{
	int i;
	int length;
	char *str[N];

	for(i = 0;i < N;i++)
	{
		length = rand() % 50 + 1;
		str[i] = atom_new(getRandomString(length),length);
		printf("str[%d] = %s\n",i,str[i]);
		usleep(300*1000);
	}

	atom_link_length();
	// for(i = 0;i < 2048;i++)
	// {
	// 	if(linkLength[i] != 0)
	// 	{
	// 		printf("%d = %d\n",i,linkLength[i]);
	// 	}
	// }
	//
	printf("------------------验证唯一性--------------\n");
	char *str1 = NULL;
	char *str2 = NULL;
	char *str3 = NULL;
	char *str4 = NULL;

	//初始化
	str1 = atom_string("hello world");
	str2 = atom_new("hello world",3);
	str3 = atom_int(-898);
	str4 = atom_string("hello world");

	printf("str1: %s----%d\n", str1, atom_length(str1));
	printf("str2: %s----%d\n", str2, atom_length(str2));
	printf("str3: %s----%d\n", str3, atom_length(str3));
	printf("str4: %s----%d\n", str4, atom_length(str4));

	//验证原子的唯一性
	printf("%08x---%08x\n", str1, str4);

	return 0;
}

#include <stdlib.h>
#include "matrix.h"

int main(int argc,char *argv[])
{
	matrix_t matrix1 = matrix_new(4,4);
	matrix_t matrix2 = matrix_new(4,4);
	matrix_t matrix_add_result;
	matrix_t matrix_sub_result;
	matrix_put(matrix1,2,3,2.0);
	matrix_put(matrix2,3,3,2.0);
	matrix_add_result = matrix_add(matrix1,matrix2);
	matrix_print(matrix_add_result);
	matrix_sub_result = matrix_sub(matrix1,matrix2);
	matrix_print(matrix_sub_result);
	// double xx = matrix_get(matrix,2,3);

}

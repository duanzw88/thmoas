#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include "mem.h"
#include "table.h"
#include "getword.h"
#include "atom.h"
#include "seq.h"

int linenum = 1;

static int compare(const void *x,const void *y)
{
	

	return strcmp(*(char **)x,*(char **)y);
}

static int first(int c)
{
	if( c == '\n')
	{
		linenum++;
	}

	return isalpha(c) || c == '_';
}
static int rest(int c)
{
	return isalpha(c) || c == '_' || isdigit(c);
}
void xref(const char *name,FILE *fp,table_t identifiers)
{
	char buf[128];
	if(name == NULL)
	{
		name = " ";
	}
	name = atom_string(name);
	while(getword(fp,buf,sizeof(buf),first,rest))
	{
		seq_t seq;
		table_t files;
		const char *id = atom_string(buf);
		files = table_get(identifiers,id);
		if(files == NULL)
		{
			//files表不存在 则新二级建表
			files = table_new(0,NULL,NULL);
			table_put(identifiers,id,files);
		}
		seq = table_get(files,name);
		if(seq == NULL)
		{
			seq = seq_new(0);
			table_put(files,name,seq);
		}
		{
			int *p = &linenum;
			NEW(p);
			*p = linenum;
			seq_addhi(seq,p);
		}
	}
}
void print(table_t files)
{
	int i;
	void **array = table_toArray(files,NULL);
	qsort(array,table_length(files),2 * sizeof(*array),compare);
	for(i = 0;array[i];i += 2)
	{
		if( *(char *)array[i] != '\0')
		{
			printf("\t%s:",(char *)array[i]);
		}
		{
			int j;
			int length = seq_length(array[i + 1]);
			for(j = 0;j < length;j++)
			{
				printf(" %d",*(int *)(seq_get(array[i + 1],j)  ));
			}
		}
		printf("\n");
	}
	FREE(array);


}
void print_identifies(table_t identifiers)
{
	int i;
	void **array = table_toArray(identifiers,NULL);
	int length = table_length(identifiers);

	qsort(array,table_length(identifiers),2 * sizeof(*array),compare);
	for(i = 0;array[i];i += 2)
	{
		printf("%s\n",(char *)array[i]);
		print(array[i+1]);
	}

	FREE(array);
}
int main(int argc,char *argv[])
{
	int i;

	table_t identifiers = table_new(0,NULL,NULL);
	for(i = 1;i < argc;i++)
	{
		FILE *fp = fopen(argv[i],"r");
		if(fp == NULL)
		{
			printf("file not find\n");
		}
		else
		{
			xref(argv[i],fp,identifiers);
			fclose(fp);
		}
	}

	if(argc == 1)
	{
		xref(NULL,stdin,identifiers);
	}

	print_identifies(identifiers);

	return 0;
}

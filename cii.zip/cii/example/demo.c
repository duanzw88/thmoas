#include <stdio.h>
#include "mem.h"
int cmpint(const void *x,const void *y)
{
	int xx = **(int **)x;
	int yy = **(int **)y;
	if( xx < yy )
	{
		return -1;
	}
	else if( xx < yy )
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int main()
{
	int x = 3;
	int y = 4;
	int *x1 = &x;
	int *y1 = &y;

	NEW(x1);
	NEW(y1);

	*x1 = x;
	*y1 = y;

	printf("result = %d\n",cmpint(&x1,&y1));
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>

#include "atom.h"
#include "table.h"
#include "mem.h"
#include "getword.h"

int first(int c)
{
	return isalpha(c);
}
int rest(int c)
{
	return isalpha(c) || c == '_';
}
int compare(const void *x,const void *y)
{
	return strcmp(*(char **)x,*(char **)y);
}
void wf(char *name,FILE *fp)
{
	int i;

	table_t table = table_new(0,NULL,NULL);
	char buf[128];

	while (getword(fp,buf,sizeof(buf),first,rest))
	{
		const char *word;
		int i,*count;
		//先全部转换成小写字母
		for(i = 0; buf[i] != '\0';i++)
		{
			buf[i] = tolower(buf[i]);
		}

		word = atom_string(buf);
		count = table_get(table,word);
		if(count)
		{
			(*count)++;
		}
		else
		{
			NEW(count);
			*count = 1;
			table_put(table,word,count);
		}
	}

	if(name)
	{
		printf("%s\n",name);
	}

	void **array = table_toArray(table,NULL);
	qsort(array,table_length(table),2*sizeof(*array),compare);
	for(i = 0;array[i];i+=2)
	{
		printf("%d\t%s\n",*(int *)array[i+1],(char *)array[i]);

	}
	FREE(array);

}

/**
 * @brief main函数负责获取输入的每个文件的文件指针，负责关闭文件流
 * @return [description]
 */
int main(int argc,char *argv[])
{
	int i;
	if(argc < 2)
	{
		printf("Us:getword_demo file_name\n");
		return -1;
	}
	for(i = 1;i < argc;i++)
	{
		FILE *fp = fopen(argv[i],"r");
		if(fp == NULL)
		{
			fprintf(stderr, "%s:cannot open '%s'\n",argv[i],strerror(errno));
			return EXIT_FAILURE;
		}
		else
		{
			wf(argv[i],fp);
			fclose(fp);
		}

	}
}

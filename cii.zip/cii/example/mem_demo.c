#include <stdio.h>

#include "mem.h"

void inuse(void *ptr,long size,const char *file,int line,void *cl)
{
	FILE *log = cl;

	fprintf(log,"**memory in use at %p\n",ptr);
	fprintf(log,"This block is %ld bytes long and was allocted from %s:%d\n",size,file,line);
}
int main()
{
	char *p = (char *)ALLOC(100);
	int *ptr2 = (int *)CALLOC(100,20);

	FREE(p);
	mem_leak(inuse,stdout);

	return 0;
}
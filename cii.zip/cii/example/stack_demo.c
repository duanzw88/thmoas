#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "stack.h"


char suffixStr[1024];
/*
*将中缀表达式转换成后缀表达式
*/
void changeStr(const char *str)
{
	int i;
	int j = 0;
	char ch;
	stack_tt stack = stack_new();
//	printf("length = %lu\n",strlen(str));

	for(i = 0; i < strlen(str); i++)
	{
//		printf("%c\n",str[i]);
		if( (str[i] >= '0') && (str[i] <= '9'))
		{
			suffixStr[j++] = str[i];
		}
		else
		{
			if((i != 0))
			{
				suffixStr[j++] = ' ';
			}
			if( ('+' == str[i]) || ('-' == str[i]))
			{
				if(stack_empty(stack))
				{
					stack_push(stack,(void *)str[i]);
				}
				else
				{
					do
					{
						ch = (char)stack_pop(stack);
						if('(' == ch)
						{
							stack_push(stack,(void *)ch);
						}
						else
						{
							suffixStr[j++] = ch;
							suffixStr[j++] = ' ';
						}
					}while(!stack_empty(stack) && ('(' != ch));
					stack_push(stack,str[i]);
				}
			}
			else if(('*' == str[i]) || ('/' == str[i]) || ('(' == str[i]))
			{
				stack_push(stack,(void *)str[i]);
			}
			else if(')' == str[i])
			{
				ch = (char)stack_pop(stack);
				while('(' != ch)
				{
					suffixStr[j++] = ch;
					suffixStr[j++] = ' ';
					ch = (char)stack_pop(stack);
				}
			}
			else
			{
				printf("error----\n");
			}

		}
	}
	suffixStr[j++] = ' ';
	while(!stack_empty(stack))
	{

		ch = (char)stack_pop(stack);
		suffixStr[j++] = ch;
		suffixStr[j++] = ' ';
	}

	stack_free(&stack);

}
// /*
// *计算后缀表达式的值
// */
int calcSuffix(char *str)
{
	stack_tt stack = stack_new();

	printf("str = %s\n",str);
	int i;
	int sum = 0;
	for(i = 0; i < strlen(str);i++)
	{
//		printf("%c\n",str[i]);
		if( (str[i] >= '0') && (str[i] <= '9') )
		{
			int num1 = 0;
			int num2 = 0;
			while((str[i] >= '0') && (str[i] <= '9'))
			{

				num1 = str[i] - '0';
				num2 = num2 * 10 + num1;

				i++;
			}
			stack_push(stack,(void *)num2);
		}
		else if(!isspace(str[i]))
		{
			int num1 = 0;
			int num2 = 0;
			int result = 0;
//			printf("operator = %c\n",str[i]);
			num1 = (int)stack_pop(stack);
			num2 = (int)stack_pop(stack);
//			printf("num1 = %d\t num2 = %d\n",num1,num2);
			if('+' == str[i])
			{
				result = num2 + num1;
			}
			else if('-' == str[i])
			{
				result = num2 - num1;
			}
			else if('*' == str[i])
			{
				result = num2 * num1;
			}
			else if('/' == str[i])
			{
				result = num2 / num1;
			}
//			printf("result = %d\n",result);
			//在32位的机器上,int和指针的长度都是4个字节,所以把int强制转换为指针没问题
			//在64位的机器上,int是4个字节，指针是8个字节，所以把int强制转换位指针会警告或者报错
			//所以需要把result转换为long之后在强制转换位void *
			stack_push(stack,(void *)(long)result);
		}

	}


	sum = (int)stack_pop(stack);
	if(!stack_empty(stack))
	{
		printf("出错... 请检查表达式是否正确\n");
	}
	stack_free(&stack);
	return sum;

}
int main()
{
	int result;
	char *p = "1+2*3+(44*5+66)/7";
	printf("中缀表达式:%s\n",p);
	printf("------------中缀表达式转换成后缀表达式------------\n");
	changeStr(p);
	printf("后缀表达式:%s\n",suffixStr);
	printf("------------计算后缀表达式的值------------\n");
	result = calcSuffix(suffixStr);
	printf("结果:%d\n",result);

	return 0;
}

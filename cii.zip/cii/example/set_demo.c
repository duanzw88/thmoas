#include <stdio.h>
#include "mem.h"
#include "set.h"

static void print(const void *member,void *cl)
{
	int x = *(int *)member;
	// printf("%d\n",x);
	fprintf(cl,"%p:%d\n",member,x);
}
int main()
{
	int i;
	set_t set = set_new(0,NULL,NULL);
	for(i = 0;i < 10;i++)
	{
		int *p = &i;
		if(!set_member(set,p))
		{
			NEW(p);
			*p = i;
			set_put(set,p);
		}
	}

	printf("--------set_toArray------\n");
	void **lines = set_toArray(set, NULL);
	for(i = 0;i < set_length(set);i++)
	{
		printf(" %p\n",(int *)lines[i]);
	}
	printf("--------set_map------\n");
	set_map(set,print,stdout);


	printf("sizeof (void *) = %lu\n",sizeof(void *));
	printf("sizeof (int) = %lu\n",sizeof(int));
	printf("sizeof (long) = %lu\n",sizeof(long));
	// set_map(set,print,stdout);

	// set_free(&set);

	return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include "mem.h"
#include "getword.h"
#include "atom.h"
#include "table.h"
#include "set.h"

int linenum;
int compare(const void *x,const void *y)
{
	return strcmp(*(char **)x,*(char **)y);
}
int cmpint(const void *x,const void *y)
{
	int xx = **(int **)x;
	int yy = **(int **)y;
	if( xx < yy )
	{
		return -1;
	}
	else if( xx < yy )
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int intcmp(const void *x,const void *y)
{
	return cmpint(&x,&y);
}
unsigned inthash(const void *x)
{
	return *(int *)x;
}
int first(int c)
{
	if(c == '\n')
	{
		linenum++;
	}
	return isalpha(c) || c == '_';
}
int rest(int c)
{
	return isalpha(c) || c == '_' || isdigit(c);
}

// void print(table_t files)
// {
// 	int i;
// 	void **array = table_toArray(files,NULL);
// 	qsort(array,table_length(files),2 * sizeof(*array),compare);
// 	for(i = 0;array[i];i+=2)
// 	{
// 		if(*(char *)array[i] != '\0')
// 		{
// 			printf("\t%s:",(char *)array[i]);
// 		}
// 		int j;
// 		void **line = set_toArray(array[i + 1],NULL);
// 		qsort(lines,set_length(array[i+1]),sizeof(*lines),cmpint);
// 		for(j = 0;lines[j];j++)
// 		{
// 			printf(" %d",*(int *)lines[j]);
// 		}
// 		FREE(line);
// 		printf("\n");
// 	}
// }
//
//
void print(table_t files)
{
	int i;
	void **array = table_toArray(files,NULL);
	qsort(array,table_length(files),2*sizeof(*array),compare);
	for(i = 0;array[i];i+=2)
	{
		if(*(char *)array[i] != '\0')
		{
			printf("\t%s:",(char *)array[i]);
		}
		{
			int j;
			void **lines = set_toArray(array[i+1], NULL);
			qsort(lines, set_length(array[i+1]), sizeof (*lines),
				cmpint);
			for (j = 0; lines[j]; j++)
				printf(" %d", *(int *)lines[j]);
			FREE(lines);
		}
		printf("\n");
	}
	FREE(array);
}
/**
 * 打印标识符
 * @param table 标识符所在的表
 */
void print_identifies(table_t identifiers)
{
	int i;
	void **array = table_toArray(identifiers,NULL);
	int length = table_length(identifiers);
	printf("length = %d\n",length);
	qsort(array,table_length(identifiers),2*sizeof(*array),compare);
	for(i = 0; array[i];i += 2)
	{
		printf("%s\n",(char *)array[i]);
		print(array[i+1]);
	}
	FREE(array);
}

void xref(const char *name,FILE *fp,table_t identifiers)
{
	char buf[128];
	// if(name == NULL)
	// {
	// 	name = " ";
	// }
	// name = atom_string(name);
	// while(getword(fp,buf,sizeof(buf),first,rest))
	// {
	// 	// set_t set;
	// 	// const void *key;
	// 	int *key;
	// 	table_t files;
	// 	const char *id = atom_string(buf);
	// 	files = table_get(identifiers,id);
	// 	if(files == NULL)
	// 	{
	// 		files = table_new(0,NULL,NULL);
	// 		table_put(identifiers,id,files);
	// 	}
	// 	key = table_get(files,name);
	// 	if(!key)
	// 	{
	// 		NEW(key);
	// 		*key = 1;
	// 		table_put(files,name,key);
	// 	}
	// }

	if(name == NULL)
	{
		name = " ";
	}
	name = atom_string(name);
	printf("name = %s\n",name);
	while(getword(fp,buf,sizeof(buf),first,rest))
	{
		// printf("buf = %s\n",buf);
		set_t set;
		table_t files;
		const char *id = atom_string(buf);
		files = table_get(identifiers,id);
		// printf("id = %s\n",id);
		if(files == NULL)
		{
			files = table_new(0,NULL,NULL);
			table_put(identifiers,id,files);
		}
		set = table_get(files,name);
		if(set == NULL)
		{
			set = set_new(0,intcmp,inthash);
			table_put(files,name,set);
		}
		{
			int *p = &linenum;
			if(!set_member(set,p))
			{
				NEW(p);
				*p = linenum;
				set_put(set,p);
			}
		}
	}

}
int main(int argc,char *argv[])
{
	int i;
	table_t identifiers = table_new(0,NULL,NULL);

	for(i = 1; i < argc; i++)
	{
		// printf("argv[%d]:%s\n",i,argv[i]);
		FILE *fp = fopen(argv[i],"r");
		if(fp == NULL)
		{
			printf("file not find\n");
		}
		else
		{
			xref(argv[i],fp,identifiers);
			fclose(fp);
		}
	}
	if(argc == 1)
	{
		xref(NULL,stdin,identifiers);
	}
	print_identifies(identifiers);


	return 0;
}

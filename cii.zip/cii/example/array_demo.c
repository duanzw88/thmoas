#include <stdio.h>
#include "mem.h"
#include "array.h"
#include "arrayrep.h"

#define LENGTH 10
#define RESIZE_LENGTH 15
int main(int argc,char *argv[])
{
	int i;
	int item;
	array_t array = array_new(LENGTH,sizeof(int));
	for(i = 0;i <  LENGTH; i++)
	{
		int *p;
		NEW(p);
		*p = i + 1;
		array_put(array,i,p);
	}

	for(i = 0;i < LENGTH;i++)
	{
		item = *(int *)array_get(array,i);
		printf("item %d:%d\n",i,item);
	}
	printf("length = %d\n",array_length(array));
	printf("size = %d\n",array_size(array));
	printf("---------resize-------------\n");
	array_resize(array,RESIZE_LENGTH);
	for(i = 0;i < RESIZE_LENGTH;i++)
	{
		item = *(int *)array_get(array,i);
		printf("item %d:%d\n",i,item);
	}
	printf("length = %d\n",array_length(array));
	printf("size = %d\n",array_size(array));

	printf("---------copy first 8-------------\n");
	array_t copy = array_copy(array,8);
	for(i = 0;i < 8;i++)
	{
		item = *(int *)array_get(array,i);
		printf("item %d:%d\n",i,item);
	}
	printf("length = %d\n",array_length(array));
	printf("size = %d\n",array_size(array));

	array_free(&copy);
	array_free(&array);
}

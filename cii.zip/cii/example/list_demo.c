
#include <stdio.h>
#include "list.h"


static void print(void **x,void *cl)
{
	char *str = (char *)*x;
	fprintf(cl, "%s\n",str);
}
int main()
{
	list_t list1,list2;
	int index = 0;

	char **array;
	list1 = list_list("abc","def","gh","XXX",NULL);


	list2 = list_push(NULL,"---");
	list_append(list1,list2);
	list1 = list_reverse(list1);
	list_map(list1,print,stdout);


	printf("length = %d\n",list_length(list1));

	array = (char **)list_toArray(list1,NULL);
	for(index = 0; array[index];index++)
	{
		printf("array[%d] = %s\n",index,array[index]);
	}


}

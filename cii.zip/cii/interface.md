# cii接口文档
## 1.原子
### 1.1 说明  
- 原子是一个指针，指向一个唯一的、不可变的序列，序列中包含零活多个字节  
- 任一原子只会出现一次，这也是被称作原子的原因  
- 如果两个原子指向相同的位置，那么二者是相同的

### 1.2 接口  
- atom_new  
    新建一个原子，如果有必要的话，它将该序列的一个副本添加到原子，并返回该原子，即指向原子表中该序列副本的指针

    ```
    const char* atom_new(const char *str,int len)  
    参数:  
    str:指向一个指针序列的指针  
    len:该序列的长度
    返回值:  
        从不返回NULL值  
    说明：
        atom_new会在必要时添加零字符
    ```  
- atom_string(const char *str)  
    将字符串用作原子  

    ```
    const char *atom_string(const char *str)  
    参数：  
    str：以0结尾的字符串
    返回值：  
        将字符串添加到原子表，返回该原子  
    说明：
        无
    ```  
- atom_int(long int)  
    将整数作为原子  

    ```
    const char *atom_int(long n)
    参数：  
    n： 要转换成原子的长整数
    返回值：  
        返回以字符串表示长整数n的原子
    说明：

    ```  
- atom_length  
    获取原子长度  

    ```
    int atom_length(const char *str)
    参数：
    str   
    返回值：
        返回其参数原子的长度
    说明：  
        atom_length的执行时间与原子的数目成正比
    ```

## 2.内存管理  
### 2.1 说明
- 标准C库提供了4个内存管理接口：*malloc*、*calloc*、*realloc*、*free*  
- mem接口将C标准库提供的接口进行封装为一组宏和接口，使之不那么容易出错，并提供了一些额外的功能。

### 2.2 接口

- 分配内存  
分配一块至少为nbytes长的内存，并返回指向其中第一个字节的指针。该内存块对齐到边界地址，能够适合最严格对齐要求的数据。该内存是未初始化的

```
//NEW接口仅适用于要分配的字节数在编译时已知
#define NEW(p) 		((p) = ALLOC((long)sizeof *(p)))
#define ALLOC(nbytes) mem_alloc((nbytes),__FILE__,__LINE__)
void *mem_alloc(long nbytes,const char *file,int line);
nbytes		分配最少的内存长度
file		申请分配的代码所在的文件
line		申请分配代码的所在的行号

```
- 分配足够大的内存
分配一个足够大的内存，可以容纳一个包含count个元素的数组，每个数组项的长度为nbytes,并返回指向第一个数组元素的指针，该内存块的对于与*mem_alloc*类似，其内容初始化为0。
count和nbytes不是正数是已检查运行时错误。

```
#define NEW0(p) 	((p) = CALLOC(1,(long)sizeof *(p)))
#define CALLOC(count,nbytes) mem_calloc((count),(nbytes),__FILE__,__LINE__)
void *mem_calloc(long count,long nbytes,const char *file,int line);  
count 	数组个数
bytes 每个数组的长度
file  申请内存的代码所在的文件
line  申请内存的代码所在的行号
```
- 释放内存  
 该接口需要一个指向被释放内存块的指针作为参数。如果ptr不为NULL指针，那么释放该内存块，如果ptr是NULL指针，该接口没有效果。  

```
#define FREE(ptr)	((void)(mem_free((ptr),__FILE__,__LINE__),(ptr) = 0))
void mem_free(void *ptr,const char *file,int line);
ptr		需要被释放的内存块的指针
file  申请内存的代码所在的文件
line  申请内存的代码所在的行号  

```
- 重新分配内存块  

```
#define RESIZE(ptr,nbytes) ((ptr) = mem_resize((ptr),(nbytes),__FILE__,__LINE__))
void *mem_resize(void *ptr,long nbytes,const char *file,int line);
ptr		需要改变长度内存块的地址
nbytes 扩展或缩减内存块，使之包含至少nbytes字节
file  申请内存的代码所在的文件
line  申请内存的代码所在的行号
```


## 4.再谈内存管理  
### 4.1 说明  
 * malloc和free的大多数实现，都会使用基于分配对象大小的内存管理算法。
 * 本章的接口实现使用了基于内存池(arena)的算法，其分配的内存来自一个内存池，使用完毕后立即释放整个内存池。
 * 基于内存池的分配器，不必像malloc/free那样，每次调用malloc返回的指针调用free，只需要一个调用，即可释放上一次释放操作以来内存池中分配的所有内存。
 * 有点:简化代码
 * 缺点:它可能使用更多的内存，而且可能造成悬挂指针。内存池中分配的对象的释放时间迟于预期，这会造成内存泄露   

### 4.2 接口  
- 创建一个内存池  

```
extern T 	arena_new(void);

```
- 释放

```
//释放与*ap内存池相关联的内存
extern void arena_dispose(T *ap);
//释放内存池中所有的内存
extern void arena_free(T arena);
```
- 分配内存块
  分配的内存块都是基于内存池的

```
//内存池分配函数
extern void *arena_alloc(T arena,long nbytes,const char *file,int line);
extern void *arena_calloc(T arena,long count,long nbytes,const char *file,int line);
```

## 5.链表
### 5.1 说明
    链表是零或多个指针的序列。包含零个指针的链表是空链表。
### 5.2 接口  
- list_append
    将一个链表附加到另一个链表后
```
T		list_append(T list,T tail);
该函数将tail赋值给list中最后一个节点rest字段，如果list为NULL，该函数返回tail。
```
- list_copy
    拷贝链表
```
	T 		list_copy(T list);
```
- list_list
    创建并返回一个链表
```
//传递N+1个指针作为参数，前N个非空，最后一个为NULL
extern 	T		list_list(void *x,...);  
```
- list_pop
   给定一个非空链表，将第一个节点的first字段赋值给*x，移除第一个节点并释放其内存，最后返回结果链表
```
extern 	T 		list_pop(T list,void **x);   
```
- list_push
 在链表的起始处添加一个包含x的新节点，并返回新的链表。   
 ```
  T 		list_push(T list,void *x);
 ```
 该接口是创建新链表的另一种方法,例如：
 ```
 p2 = list_push(NULL,"List");
 p2 = list_push(p2,"Arena");
 p2 = list_push(NULL,"Mem");
 ```
- list_reverse
    逆转链表，首先是逆转其参数链表中节点的顺序，而后返回结果链表
```
T 		list_reverse(T list);
```
- list_length  
    链表的节点数目
```
int 	list_length(T list);
```
- list_free  
释放链表中的所有节点并将其设置为NULL指针
```
void 	list_free(T *list);
```  
- list_map  
    对list的链表中的每个节点调用apply指向的函数
```
void 	list_map(T list,void apply(void **x,void *cl),void *cl);
```
- list_toArray
    把链表中节点的数据转换成数组，数组中的元素0到N-1分别包含了链表中N个节点的first字段值。
```
void 	**list_toArray(T list,void *end);
```
## 6.表
### 6.1 说明
	关联表是一组键-值对的集合，它很像数组，只是索引可以是任何类型值。
	Table接口的设计使得它可以满足很多用途，它维护键值对，但从不查看键本身，只有客户程序才通过传递给Table中例程函数来查看键值。
### 6.2 

- table_new  
 创建表，参数hint用户估计新的表中预期会容纳的表项目数。无论hint值为何，所有表都可以容纳任意数目的表项，但是准确的hint值可能会提高性能。

	```
T    table_new(int hint,int cmp(const void *x,const void *y),unsigned hash(const void *key));
	cmp  表的比较函数
	hash 根据key值返回hash码(哈希函数)
	```
- table_free
 释放表
 
	```
	void    table_free(T *table);
	```
- table_length
查询表中的键值对个数

	```
	extern int  table_length(T table);
	```
- table_put  
添加键值对到表中,如果key已经存在,则用value覆盖key此前对应的值

	```
	void *table_put(T table,const void *key,void *value);
	```

- table_get
根据键查找值

	```
	void *table_get(T table,const void *key);
	```
- table_remove
 删除键值对
 
	```
	void *table_remove(T table,const void *key);
	```

- table_map  
  以未指定的顺序对table中的每一个键值对调用apply指向的函数  
  
	```
	void table_map(T table,void apply(const void *key,void **value,void *cl),void *cl);
	```
	
- table_toArray
	访问表中的每一个键值对，并将其收集到一个数组中
	
	```
	void **table_toArray(T table,void *end);
	```
## 7.集合
### 7.1 说明
 	* 集合是不同成员的无序汇集。
 	* 对集合的基本操作包括检验成员资格、添加成员和删除成员
 	* 其他操作包括集合的并、交、差和对称差
 	
### 7.2 接口
- set_new  
  分配、初始化一个新的T实例  

	```
	T set_new(int hint,int cmp(const void *x,const void *y),unsigned hash(const void *x));
	hint  对集合预期会包含的成员数目的一个估计，准确的hint值会提高性能，任何非负值都是可接受的
	cmp	 用来比较两个成员
	hash	 用来将成员映射到无符号整数
	
	说明:cmp(x,y)针对x小于y x等于y x大于y的情形必须分别返回小于0 等于0 大于0的整数
	    如果cmp(x,y)返回0，那么x和y只有一个会出现在集合中，而且hash(x)必定等于hash(y)
	    如果cmp为NULL函数指针，那么假定集合成员为原子，采用默认比较函数
	    如果hash为NULL函数指针，采用默认hash函数
	```
- set_free  
	释放集合资源  
	
	```
	void set_free(T *set);
	```

- set_length
 获取集合的势,即长度  
 
	```
	int 	set_length(T set);
	```
- set_member  
  查询member是否在集合中  
  
	```
	 int 	set_member(T set,const void *member);
	```
- set_put
	向set中添加成员  
	
	```
	void set_put(T set,const void *member);
	set    集合对象
	member 要添加的成员
	```
- set_remove  
	删除成员  
	
	```
	void *set_remove(T set,const void *member);
	set    集合对象
	member 要删除的成员member在set中,删除的成员;member不在set中,返回NULL
	```

- set_map    
 对集合每个成员都调用apply函数  
 
	```
	extern void set_map(T set, void apply(const void *member,void *cl),void *cl);
	```
- set_toArray  
	把集合转换为数组  
	
	```
	void **set_toArray(T set,void *end);
	set 集合对象
	end 赋值给数组的第N+1个元素
	
	```
- set_unioon  
	并集 
	 
	```
	T set_unioon(T s,T t);
	```

-  set_inter  
	交集
	
	```
	T set_inter(T s,T t);
	```

- set_minus  
  差集
	  
	```
	T set_minus(T s,T t);
	```
- set_diff  
	对称差   
	 
	```
	T set_diff(T s,T t);
	```

## 8.动态数组
## 9.序列
## 10.环

#ifndef _FMT_H
#define _FMT_H

#include <stdarg.h>
#include <stdio.h>
#include "except.h"

#define T fmt_t
typedef void (*T)(int code,va_list *app,int put(int c,void *cl),void *cl,unsigned char flags[256],int width,int precision);

extern char *fmt_flags;
extern const Except_t fmt_Overflow;

/**
 * 按照第三个参数fmt的格式串来格式化第四个和后续参数
 * 并调用put(c,cl)来输出每个格式化完毕的字符c，c当做unsigned char处理
 * @param cl [description]
 */
extern void fmt_fmt(int put(int c,void *cl),void *cl,const char *fmt, ...);

/**
 * 按照fmt的格式串来格式化ap指向的各个参数
 * @param cl [description]
 */
extern void fmt_vfmt(int put(int c,void *cl),void *cl,const char *fmt,va_list ap);

/**
 * 格式化输出写到标准输出
 * @param fmt     格式化
 * @param VARARGS 参数
 */
extern void fmt_printf(const char *fmt,...);
/**
 * 按照fmt给定的格式来格式化第三个个和后续参数，并将格式化输出写到指定的流中
 * @param stream  流
 * @param fmt     格式化
 * @param VARARGS 参数
 */
extern void fmt_fprintf(FILE *stream,const char *fmt,...);
/**
 * 按照fmt给定的格式串来格式化第四个和后续参数，将格式化输出以0结尾字符串形式，存储到buf[0..size-1]中
 * @param  buf     buf
 * @param  size    大小
 * @param  fmt     格式化
 * @param  VARARGS 参数
 * @return         返回存储到buf中的个数
 */
extern int 	fmt_sfmt(char *buf,int size,const char *fmt,...);

extern int 	fmt_vsfmt(char *buf,int size,const char *fmt,va_list ap);
extern char *fmt_string(const char *fmt,...);
extern char *fmt_vsstring(const char *fmt,va_list ap);

extern T fmt_register(int code,T cvt);

#undef T
#endif

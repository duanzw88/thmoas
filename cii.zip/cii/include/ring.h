#ifndef _RING_H
#define _RING_H

#define T ring_t
typedef struct T *T;


/**
 * 创建一个空环
 * @return  返回新创建的空环
 */
extern T 		ring_new(void);

/**
 * 创建并返回一个环，用非NULL的值来初始化环中的值，参数列表结束于第一个NULL指针参数
 * @param  x       环的第一个元素
 * @param  VARARGS 非NULL值来初始化环中的值
 * @return         返回根据参数新建的环
 *
 * ps：参数列表的可变部分传递的指针假定为void指针，因此在传递char或void以外的指针时
 * 		需要程序员提供转换
 */
extern T 		ring_ring(void *x, ...);

/**
 * 释放*ring指定的环，并将*ring清零
 * @param  ring 目标环
 */
extern void 	ring_free(T *ring);

/**
 * 环的长度
 * @param  ring 目标环
 * @return      目标环的长度
 */
extern int 		ring_length(T ring);

/**
 * 获取环中的索引为i的值
 * @param  ring 目标环
 * @param  i    索引值
 * @return      索引i的值
 */
extern void 	*ring_get(T ring,int i);

/**
 * 更新环中索引为i的值
 * @param  ring 目标环
 * @param  i    索引
 * @param  x    新值
 * @return      返回原值
 */
extern void 	*ring_put(T ring,int i,void *x);

/**
 * 在环中添加新值,添加新值后，其右侧的所有值的索引+1，环的长度+1
 * @param  ring 目标环
 * @param  pos  要添加的新值的位置
 * @param  x    要添加的值
 * @return      返回新值
 */
extern void 	*ring_add(T ring,int pos,void *x);

/**
 * 等效于ring_add(ring,1,x)在开始出添加新值
 * @param  ring 目标环
 * @param  x    要添加的新值
 * @return      返回新值
 */
extern void 	*ring_addlo(T ring,void *x);

/**
 * 等效于ring_add(ring,0,x)在尾部添加新值
 * @param  ring 目标环
 * @param  x    要添加的新值
 * @return      返回新值
 */
extern void 	*ring_addhi(T ring,void *x);

/**
 * 在环中根据索引值删除值，删除后其右侧剩下的值索引都-1，环的长度-1
 * @param  ring 目标环
 * @param  i    索引值
 * @return      返回删除的值
 */
extern void 	*ring_remove(T ring,int i);

/**
 * 删除环低端(开始处)的值，等效于ring_remove(ring,0)
 * @param  ring 目标环
 * @return      返回删除的值
 */
extern void 	*ring_remlo(T ring);

/**
 * 删除环高端(末尾)的值，等效于ring_remove(ring,ring_length(ring)-1)
 * @param  ring 目标环
 * @return      返回删除的值
 */
extern void 	*ring_remhi(T ring);

/**
 * 将环左旋或右旋
 * @param  ring 目标环
 * @param  n    n>0 将换右旋n个值，n<0将环左旋n个值
 *
 * @other n模环的长度为0的话 该函数没有效果，
 *        n的绝对值大于ring的长度，是已检查的运行时错误
 */
extern void 	ring_rotate(T ring,int n);

#undef T
#endif

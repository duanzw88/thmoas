#ifndef _BIT_H
#define _BIT_H

#define T bit_t
typedef struct T *T;

/**
 * 创建一个包含length个比特位的新向量，并将所有bit位都设置为0
 * @param  length 新向量bit位的长度
 * @return        返回新的向量
 */
extern T 		bit_new(int length);

/**
 * 返回向量中的bit位数
 * @param  set 目标向量
 * @return     返回bit的位数
 */
extern int 		bit_length(T set);

/**
 * 查询向量中1的数目，即置位的比特位数
 * @param  set 目标向量
 * @return     返回目标向量中1的个数
 */
extern int 		bit_count(T set);

/**
 * 释放*set并将*set清零
 * @param  set 目标bit集合
 * @return     无
 */
extern void 	bit_free(T *set);

/**
 * 获取比特位n
 * @param  set 比特位集合
 * @param  i   索引
 * @return     返回bit位n
 */
extern int 		bit_get(T set,int i);

/**
 * 将集合中bit位n设置为bit
 * @param  set 比特位集合
 * @param  n   比特位索引
 * @param  bit 新值
 * @return     返回该比特位原值
 */
extern int 		bit_put(T set,int n,int bit);
/**
 * 将lo到hi的所有比特位清零
 * @return     无
 */
extern void 	bit_clear(T set,int lo,int hi);
/**
 * 将lo到hi的所有比特位置位
 * @return     无
 */
extern void 	bit_set(T set,int lo,int hi);
/**
 * 将lo到hi的所有比特位取反
 * @return     无
 */
extern void 	bit_not(T set,int lo,int hi);

/**
 * @return   s ⊂ t 返回1 否则返回0
 */
extern void 	bit_lt(T s,T t);
/**
 * @return   s = t 返回1 否则返回0
 */
extern void 	bit_eq(T s,T t);
/**
 * @return   s ⊆ t 返回1 否则返回0
 */
extern void 	bit_leq(T s,T t);

extern void 	bit_map(T set,void apply(int n,int bit,void *cl),void *cl);

//集合操作
//并集
extern T 		bit_union(T s,T t);
//交集
extern T 		bit_inter(T s,T t);
//差集
extern T 		bit_mins(T s,T t);
//对称差
extern T 		bit_diff(T s,T t);

#undef T
#endif

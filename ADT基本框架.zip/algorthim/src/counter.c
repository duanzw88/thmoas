
#include "counter.h"

T 	counter_new(char *name)
{

}
void counter_increment(T counter)
{

}
int 	counter_get_tally(T counter)
{

}
char *counter_tostring(T counter)
{
	
}

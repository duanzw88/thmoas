#ifndef __COUNTER_H__
#define __COUNTER_H__

#define T counter_t

extern T 	counter_new(char *name);
extern void counter_increment(T counter);
extern int 	counter_get_tally(T counter);
extern char *counter_tostring(T counter);

#endif

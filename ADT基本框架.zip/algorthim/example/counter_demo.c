
#include <stdlib.h>
#include <stdio.h>
#include "counter.h"

int main()
{
	printf("result = %d\n",add(1,2));
}
